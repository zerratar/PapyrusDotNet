﻿using PapyrusDotNet.Core;

namespace Example1
{
    public class LambdaTest : ObjectReference
    {

        public override void OnInit()
        {
            

        }
    }
}
