﻿namespace PapyrusDotNet.Common.Papyrus
{
    public interface ILabelDefinition
    {
        string Name { get; set; }
        int Row { get; set; }
    }
}