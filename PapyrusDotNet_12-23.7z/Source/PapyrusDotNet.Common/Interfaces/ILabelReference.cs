﻿namespace PapyrusDotNet.Common.Interfaces
{
    public interface ILabelReference
    {
        string Name { get; set; }
        int RowReference { get; set; }
    }
}