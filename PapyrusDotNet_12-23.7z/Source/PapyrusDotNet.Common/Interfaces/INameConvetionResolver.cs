using PapyrusDotNet.Common.Interfaces;

namespace PapyrusDotNet.Converters.Papyrus2Clr.Implementations
{
    public interface INameConvetionResolver : ITypeNameResolver { }
}