namespace PapyrusDotNet.Common.Interfaces
{
    public interface IUtility
    {        
    }
}