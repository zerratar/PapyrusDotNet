namespace PapyrusDotNet.Common.Enums
{
    public enum Games
    {
        Fallout4,
        Skyrim
    }
}