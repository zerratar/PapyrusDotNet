using System;

namespace PapyrusDotNet.Converters.Clr2Papyrus.Exceptions
{
    public class InvalidPropertyAccessException : Exception
    {
    }
}